package org.example;

import java.sql.*;
import java.util.List;

import com.github.britooo.looca.api.core.Looca;
import com.github.britooo.looca.api.group.discos.Disco;
import com.github.britooo.looca.api.group.discos.DiscoGrupo;
import com.github.britooo.looca.api.group.discos.Volume;
import com.github.britooo.looca.api.group.memoria.Memoria;
import com.github.britooo.looca.api.group.processador.Processador;
import com.github.britooo.looca.api.group.sistema.Sistema;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;


public class Main {
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_PURPLE = "\u001B[35m";


    public static void main(String[] args) throws InterruptedException {
        Double usoMemoriaPorcentagem;
        Double usoCpu;
        Double volumeEmUsoPorcentagem;
        while (true) {
            Looca looca = new Looca();
            //Informacoes do sistema operacional (nao insere no banco, somente informacoes adicionais)
            Sistema sistema = looca.getSistema();
            System.out.println(ANSI_PURPLE + "INFORMAÇÕES DO SISTEMA OPRACIONAL: \n" + ANSI_RESET);
            System.out.println(sistema);

            //Informacoes da memoria (vai inserir no banco)
            Memoria memoria = looca.getMemoria();
            System.out.println(ANSI_PURPLE + "INFORMAÇÕES DA MEMÓRIA" + ANSI_RESET);
            System.out.println(memoria);

            Double usoMemoriaGB = memoria.getEmUso() / (1024.0 * 1024.0 * 1024.0);
            Double totalMemoriaGB = memoria.getTotal() / (1024.0 * 1024.0 * 1024.0);

            usoMemoriaPorcentagem = (usoMemoriaGB / totalMemoriaGB) * 100;


            //Informacoes do processador (Somante um dado vai ao banco)
            Processador processador = looca.getProcessador();
            System.out.println(ANSI_PURPLE + "INFORMAÇÕES DO PROCESSADOR" + ANSI_RESET);
            System.out.println(processador);

            usoCpu = processador.getUso();


            //Informacoes do disco (Vai pro banco)
            DiscoGrupo grupoDeDiscos = looca.getGrupoDeDiscos();
            List<Disco> discos = grupoDeDiscos.getDiscos();
            List<Volume> volumes = grupoDeDiscos.getVolumes();
            System.out.println(ANSI_PURPLE + "INFORMAÇÕES DO DISCO" + ANSI_RESET);
            for (Disco disco : discos) {
                System.out.println(disco);
            }

            Double volumeTotal = 0.0;
            Double volumeDisponivel = 0.0;
            Double volumeEmUso = 0.0;
            volumeEmUsoPorcentagem = 0.0;

            for (Volume volume : volumes) {
                System.out.println(volume);
                volumeTotal = (double) volume.getTotal();
                volumeDisponivel = (double) volume.getDisponivel();
                volumeEmUso = (volumeTotal - volumeDisponivel);
                volumeEmUsoPorcentagem = (volumeEmUso / volumeTotal) * 100;
            }

            inserirDadosEc2(usoMemoriaPorcentagem, usoCpu, volumeEmUsoPorcentagem);

            Thread.sleep(5000);
        }
    }

    public static void inserirDadosEc2(Double usoMemoriaPorcentagem, Double usoCpu, Double volumeEmUsoPorcentagem) {
        String jdbcUrl = "jdbc:mysql://18.210.33.55:3306/bankSecure";
        String username = "root";
        String password = "urubu100";

        try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)){
            String sql1 = "insert into registros (fkMaquina, fkComponente, valor, dataHora) values (2, 1, ?, ?)";
            String sql2 = "insert into registros (fkMaquina, fkComponente, valor, dataHora) values (2, 2, ?, ?)";
            String sql3 = "insert into registros (fkMaquina, fkComponente, valor, dataHora) values (2, 3, ?, ?)";

            try (PreparedStatement statement = connection.prepareStatement(sql1)){
                statement.setDouble(1, usoCpu);
                statement.setTimestamp(2, new Timestamp(new Date().getTime()));

                statement.executeUpdate();
            }

            try (PreparedStatement statement = connection.prepareStatement(sql2)){
                statement.setDouble(1, volumeEmUsoPorcentagem);
                statement.setTimestamp(2, new Timestamp(new Date().getTime()));

                statement.executeUpdate();
            }

            try (PreparedStatement statement = connection.prepareStatement(sql3)){
                statement.setDouble(1, usoMemoriaPorcentagem);
                statement.setTimestamp(2, new Timestamp(new Date().getTime()));

                statement.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}



